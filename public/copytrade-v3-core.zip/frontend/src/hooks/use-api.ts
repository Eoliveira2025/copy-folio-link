/**
 * React Query hooks for all API endpoints.
 */
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import type { CreatePlanData, CreateTermsData, UpdateTermsData, RiskSettingsUpdate, CreateStrategyData, CreateMasterAccountData } from "@/lib/api";
import { toast } from "sonner";

// ── MT5 Accounts ────────────────────────────────────
export function useMT5Accounts() {
  return useQuery({
    queryKey: ["mt5-accounts"],
    queryFn: () => api.listMT5Accounts(),
  });
}

export function useConnectMT5() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { login: number; password: string; server: string }) =>
      api.connectMT5(data.login, data.password, data.server),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["mt5-accounts"] });
      toast.success("MT5 account connected successfully!");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useDisconnectMT5() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (accountId: string) => api.disconnectMT5(accountId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["mt5-accounts"] });
      toast.success("MT5 account disconnected");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

// ── Strategies ──────────────────────────────────────
export function useStrategies() {
  return useQuery({
    queryKey: ["strategies"],
    queryFn: () => api.listStrategies(),
  });
}

export function useSelectStrategy() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (strategyId: string) => api.selectStrategy(strategyId),
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ["strategies"] });
      toast.success(data.message);
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useRequestStrategy() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (strategyId: string) => api.requestStrategy(strategyId),
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ["strategies"] });
      toast.success(data.message);
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

// ── Billing ─────────────────────────────────────────
export function usePlans() {
  return useQuery({
    queryKey: ["plans"],
    queryFn: () => api.listPlans(),
  });
}

export function useSubscription() {
  return useQuery({
    queryKey: ["subscription"],
    queryFn: () => api.getSubscription(),
  });
}

export function useInvoices() {
  return useQuery({
    queryKey: ["invoices"],
    queryFn: () => api.listInvoices(),
  });
}

export function useUpgradeEligibility() {
  return useQuery({
    queryKey: ["upgrade-eligibility"],
    queryFn: () => api.checkUpgradeEligibility(),
    refetchInterval: 60000,
  });
}

export function useRequestUpgrade() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (targetPlanId: string) => api.requestUpgrade(targetPlanId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["upgrade-eligibility"] });
      qc.invalidateQueries({ queryKey: ["my-upgrade-requests"] });
      toast.success("Upgrade request submitted!");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useMyUpgradeRequests() {
  return useQuery({
    queryKey: ["my-upgrade-requests"],
    queryFn: () => api.myUpgradeRequests(),
  });
}

export function useCheckout() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { plan_id: string; billing_type: string; gateway: string }) =>
      api.checkout(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["invoices"] });
      qc.invalidateQueries({ queryKey: ["subscription"] });
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminBillingStats() {
  return useQuery({
    queryKey: ["admin-billing-stats"],
    queryFn: () => api.adminBillingStats(),
  });
}

export function useAdminCancelSubscription() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (subscriptionId: string) => api.adminCancelSubscription(subscriptionId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-subscriptions"] });
      qc.invalidateQueries({ queryKey: ["admin-billing-stats"] });
      toast.success("Subscription cancelled");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminRefundInvoice() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { invoice_id: string; amount?: number; reason?: string }) =>
      api.adminRefundInvoice(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-invoices"] });
      qc.invalidateQueries({ queryKey: ["admin-billing-stats"] });
      toast.success("Refund processed");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminMarkInvoicePaid() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { invoiceId: string; note?: string }) =>
      api.adminMarkInvoicePaid(data.invoiceId, data.note),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-invoices"] });
      qc.invalidateQueries({ queryKey: ["admin-billing-stats"] });
      qc.invalidateQueries({ queryKey: ["admin-subscriptions"] });
      toast.success("Fatura marcada como paga");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminCancelInvoice() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { invoiceId: string; note?: string }) =>
      api.adminCancelInvoice(data.invoiceId, data.note),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-invoices"] });
      qc.invalidateQueries({ queryKey: ["admin-billing-stats"] });
      toast.success("Fatura cancelada");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminExtendInvoiceDueDate() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { invoiceId: string; newDueDate: string; note?: string }) =>
      api.adminExtendInvoiceDueDate(data.invoiceId, data.newDueDate, data.note),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-invoices"] });
      toast.success("Vencimento estendido");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminAddInvoiceNote() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { invoiceId: string; note: string }) =>
      api.adminAddInvoiceNote(data.invoiceId, data.note),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-invoices"] });
      toast.success("Observação adicionada");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

// ── Admin ───────────────────────────────────────────
export function useAdminUsers(search: string) {
  return useQuery({
    queryKey: ["admin-users", search],
    queryFn: () => api.adminSearchUsers(search),
  });
}

export function useAdminDashboard() {
  return useQuery({
    queryKey: ["admin-dashboard"],
    queryFn: () => api.adminGetDashboard(),
  });
}

export function useAdminCheckPayments() {
  return useMutation({
    mutationFn: () => api.adminCheckPayments(),
    onSuccess: () => toast.success("Payment check dispatched"),
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminUnblockUser() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (userId: string) => api.adminUnblockUser(userId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-users"] });
      toast.success("User unblocked");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminUnlockStrategy() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { userId: string; strategyId: string }) =>
      api.adminUnlockStrategy(data.userId, data.strategyId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-users"] });
      toast.success("Strategy unlocked");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useChangePassword() {
  return useMutation({
    mutationFn: (data: { currentPassword: string; newPassword: string }) =>
      api.changePassword(data.currentPassword, data.newPassword),
    onSuccess: () => toast.success("Password updated successfully"),
    onError: (err: Error) => toast.error(err.message),
  });
}

// ── Admin Plans ─────────────────────────────────────
export function useAdminPlans() {
  return useQuery({
    queryKey: ["admin-plans"],
    queryFn: () => api.adminListPlans(),
  });
}

export function useAdminCreatePlan() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: CreatePlanData) => api.adminCreatePlan(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-plans"] });
      toast.success("Plan created");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminUpdatePlan() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { planId: string; updates: Partial<CreatePlanData> }) =>
      api.adminUpdatePlan(data.planId, data.updates),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-plans"] });
      toast.success("Plan updated");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminDeletePlan() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (planId: string) => api.adminDeletePlan(planId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-plans"] });
      toast.success("Plan deleted");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminChangeUserPlan() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { userId: string; planId: string }) =>
      api.adminChangeUserPlan(data.userId, data.planId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-users"] });
      toast.success("User plan changed");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

// ── Admin Subscriptions & Invoices ──────────────────
export function useAdminSubscriptions(status?: string, accessStatus?: string) {
  return useQuery({
    queryKey: ["admin-subscriptions", status, accessStatus],
    queryFn: () => api.adminListSubscriptions(status, accessStatus),
  });
}

export function useAdminToggleOverride() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (subscriptionId: string) => api.adminToggleOverride(subscriptionId),
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ["admin-subscriptions"] });
      toast.success(data.message);
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminInvoices(status?: string) {
  return useQuery({
    queryKey: ["admin-invoices", status],
    queryFn: () => api.adminListInvoices(status),
  });
}

// ── Admin Upgrade Requests ─────────────────────────
export function useAdminUpgradeRequests(status?: string) {
  return useQuery({
    queryKey: ["admin-upgrade-requests", status],
    queryFn: () => api.adminListUpgradeRequests(status),
  });
}

export function useAdminHandleUpgradeRequest() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { requestId: string; action: "approve" | "reject"; note?: string }) =>
      api.adminHandleUpgradeRequest(data.requestId, data.action, data.note),
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ["admin-upgrade-requests"] });
      toast.success(data.message);
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

// ── Admin Terms ────────────────────────────────────────
export function useAdminTerms() {
  return useQuery({
    queryKey: ["admin-terms"],
    queryFn: () => api.adminListTerms(),
  });
}

export function useAdminCreateTerms() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: CreateTermsData) => api.adminCreateTerms(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-terms"] });
      toast.success("Terms created");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminUpdateTerms() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { termsId: string; updates: UpdateTermsData }) =>
      api.adminUpdateTerms(data.termsId, data.updates),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-terms"] });
      toast.success("Terms updated");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminActivateTerms() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (termsId: string) => api.adminActivateTerms(termsId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-terms"] });
      toast.success("Terms activated");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

// ── Public Settings ────────────────────────────────
export function usePublicSettings() {
  return useQuery({
    queryKey: ["public-settings"],
    queryFn: () => api.getPublicSettings(),
  });
}

export function useAdminUpdatePublicSettings() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { affiliate_broker_link: string | null }) =>
      api.adminUpdatePublicSettings(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["public-settings"] });
      toast.success("Settings updated");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

// ── Admin Risk Protection ──────────────────────────
export function useAdminRiskSettings() {
  return useQuery({
    queryKey: ["admin-risk-settings"],
    queryFn: () => api.adminGetRiskSettings(),
  });
}

export function useAdminRiskStatus() {
  return useQuery({
    queryKey: ["admin-risk-status"],
    queryFn: () => api.adminGetRiskStatus(),
    refetchInterval: 5000,
  });
}

export function useAdminRiskIncidents() {
  return useQuery({
    queryKey: ["admin-risk-incidents"],
    queryFn: () => api.adminGetRiskIncidents(),
  });
}

export function useAdminUpdateRiskSettings() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: RiskSettingsUpdate) => api.adminUpdateRiskSettings(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-risk-settings"] });
      qc.invalidateQueries({ queryKey: ["admin-risk-status"] });
      toast.success("Risk settings updated");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminResetEmergency() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => api.adminResetEmergency(),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-risk-status"] });
      qc.invalidateQueries({ queryKey: ["admin-risk-settings"] });
      toast.success("Emergency state reset — trading re-enabled");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

// ── Admin Operations ───────────────────────────────
export function useAdminOperations() {
  return useQuery({
    queryKey: ["admin-operations"],
    queryFn: () => api.adminGetOperations(),
    refetchInterval: 10000,
  });
}

// ── Admin Dead Letter Queue ────────────────────────
export function useAdminDeadLetterTrades(status?: string) {
  return useQuery({
    queryKey: ["admin-dead-letter", status],
    queryFn: () => api.adminGetDeadLetterTrades(status),
    refetchInterval: 15000,
  });
}

export function useAdminRetryDeadLetter() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (tradeId: string) => api.adminRetryDeadLetter(tradeId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-dead-letter"] });
      qc.invalidateQueries({ queryKey: ["admin-operations"] });
      toast.success("Trade re-enqueued for execution");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminResolveDeadLetter() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { tradeId: string; note: string }) =>
      api.adminResolveDeadLetter(data.tradeId, data.note),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-dead-letter"] });
      qc.invalidateQueries({ queryKey: ["admin-operations"] });
      toast.success("Trade marked as resolved");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

// ── Admin Copy Recoveries ─────────────────────────
export function useAdminRecoveries(filters: { status?: string; recovery_type?: string; limit?: number } = {}) {
  return useQuery({
    queryKey: ["admin-recoveries", filters],
    queryFn: () => api.adminGetRecoveries(filters),
    refetchInterval: 10000,
  });
}

export function useAdminRecoveriesSummary() {
  return useQuery({
    queryKey: ["admin-recoveries-summary"],
    queryFn: () => api.adminGetRecoveriesSummary(),
    refetchInterval: 15000,
  });
}

// ── Admin Provisioning ─────────────────────────────
export function useAdminPendingAccounts() {
  return useQuery({
    queryKey: ["admin-pending-accounts"],
    queryFn: () => api.adminGetPendingAccounts(),
    refetchInterval: 15000,
  });
}

export function useAdminCompleteProvision() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (accountId: string) => api.adminCompleteProvision(accountId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-pending-accounts"] });
      qc.invalidateQueries({ queryKey: ["mt5-accounts"] });
      toast.success("Account provisioned successfully!");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

// ── Admin Strategies ───────────────────────────────
export function useAdminStrategies() {
  return useQuery({
    queryKey: ["admin-strategies"],
    queryFn: () => api.adminListStrategies(),
  });
}

export function useAdminCreateStrategy() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: CreateStrategyData) => api.adminCreateStrategy(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-strategies"] });
      toast.success("Strategy created");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminUpdateStrategy() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { strategyId: string; updates: Partial<CreateStrategyData> }) =>
      api.adminUpdateStrategy(data.strategyId, data.updates),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-strategies"] });
      toast.success("Strategy updated");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminDeleteStrategy() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (strategyId: string) => api.adminDeleteStrategy(strategyId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-strategies"] });
      toast.success("Strategy deleted");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

// ── Admin Strategy Requests ────────────────────────────
export function useAdminStrategyRequests(status?: string) {
  return useQuery({
    queryKey: ["admin-strategy-requests", status],
    queryFn: () => api.adminListStrategyRequests(status),
    refetchInterval: 15000,
  });
}

export function useAdminApproveStrategyRequest() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (requestId: string) => api.adminApproveStrategyRequest(requestId),
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ["admin-strategy-requests"] });
      toast.success(data.message);
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminRejectStrategyRequest() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { requestId: string; note: string }) =>
      api.adminRejectStrategyRequest(data.requestId, data.note),
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ["admin-strategy-requests"] });
      toast.success(data.message);
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminSetMasterAccount() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { strategyId: string; masterData: CreateMasterAccountData }) =>
      api.adminSetMasterAccount(data.strategyId, data.masterData),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-strategies"] });
      toast.success("Master account configured");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}
// ── MetaApi V3 ───────────────────────────────────────
export function useAdminMetaApiAccounts() {
  return useQuery({
    queryKey: ["admin-metaapi-accounts"],
    queryFn: () => api.adminListMetaApiAccounts(),
  });
}

export function useAdminSyncMetaApiAccount() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.adminSyncMetaApiAccount(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-metaapi-accounts"] });
      toast.success("Account synced");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminMetaApiStrategies() {
  return useQuery({
    queryKey: ["admin-metaapi-strategies"],
    queryFn: () => api.adminListMetaApiStrategies(),
  });
}

export function useAdminCreateMetaApiProvider() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (strategyId: string) => api.adminCreateMetaApiProvider(strategyId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-metaapi-strategies"] });
      toast.success("Provider created successfully");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminMetaApiSubscriptions() {
  return useQuery({
    queryKey: ["admin-metaapi-subscriptions"],
    queryFn: () => api.adminListMetaApiSubscriptions(),
  });
}

export function useAdminMetaApiSwitchRequests() {
  return useQuery({
    queryKey: ["admin-metaapi-switch-requests"],
    queryFn: () => api.adminListMetaApiSwitchRequests(),
  });
}

export function useAdminForceMetaApiSwitch() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (requestId: string) => api.adminForceMetaApiSwitch(requestId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-metaapi-switch-requests"] });
      qc.invalidateQueries({ queryKey: ["admin-metaapi-subscriptions"] });
      toast.success("Switch forced successfully");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useClientMyMetaApiStatus() {
  return useQuery({
    queryKey: ["my-metaapi-status"],
    queryFn: () => api.clientGetMyMetaApiStatus(),
    refetchInterval: 30000,
  });
}

export function useClientRequestSwitch() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (targetStrategyId: string) => api.clientRequestStrategySwitch(targetStrategyId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["my-switch-status"] });
      toast.success("Switch request submitted");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useClientSwitchStatus() {
  return useQuery({
    queryKey: ["my-switch-status"],
    queryFn: () => api.clientGetSwitchStatus(),
  });
}
// ── MetaApi Reconciliation ────────────────────────────
export function useAdminReconciliationSettings() {
  return useQuery({
    queryKey: ["admin-metaapi-reconciliation-settings"],
    queryFn: () => api.adminGetReconciliationSettings(),
  });
}

export function useAdminUpdateReconciliationSettings() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: any) => api.adminUpdateReconciliationSettings(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-metaapi-reconciliation-settings"] });
      toast.success("Reconciliation settings updated");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminReconciliationEvents(status?: string) {
  return useQuery({
    queryKey: ["admin-metaapi-reconciliation-events", status],
    queryFn: () => api.adminListReconciliationEvents(status),
    refetchInterval: 30000,
  });
}

export function useAdminApproveCloseOrphan() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (eventId: string) => api.adminApproveCloseOrphan(eventId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-metaapi-reconciliation-events"] });
      toast.success("Position close approved");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminIgnoreOrphan() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (eventId: string) => api.adminIgnoreOrphan(eventId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-metaapi-reconciliation-events"] });
      toast.success("Orphan position ignored");
    },
    onError: (err: Error) => toast.error(err.message),
  });
}

export function useAdminRunReconciliation() {
  return useMutation({
    mutationFn: () => api.adminRunReconciliation(),
    onSuccess: () => toast.success("Reconciliation process started"),
    onError: (err: Error) => toast.error(err.message),
  });
}
