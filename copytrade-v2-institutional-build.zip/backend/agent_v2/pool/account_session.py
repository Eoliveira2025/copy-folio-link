"""AccountSession — serialized login per terminal/pool.

Invariants:
  * Exactly one account is "current" per terminal at any time.
  * `acquire(account_id)` blocks until the terminal lock is held AND the
    requested account is logged in. Release returns the lock.
  * Sticky: re-acquiring the *same* account skips the (slow) re-login.
  * Session has a TTL; expired sessions are re-logged on next acquire.
  * DRY-RUN by default: no real `mt5.initialize/login` call. The login
    cost is simulated so latency metrics work.

Real MT5 login lands in increment 6 (OrderExecutor).
"""

from __future__ import annotations

import os
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Optional, Callable
from uuid import UUID

from ..config import get_v2_settings
from ..utils.logger import get_logger
from ..utils.security import decrypt_mt5_password
from .repo import AccountDetails


# Toggle real MT5 login from env. Default: dry-run.
_DRY_RUN_ENV = "V2_SESSION_DRY_RUN"


def _is_dry_run() -> bool:
    val = os.environ.get(_DRY_RUN_ENV, "true").strip().lower()
    return val not in ("0", "false", "no")


@dataclass
class _SessionState:
    account_id: Optional[UUID] = None
    logged_in_at: float = 0.0  # monotonic seconds
    login_count: int = 0


class LoginFailedError(RuntimeError):
    pass


class AccountSession:
    """Per-terminal serialized login + execution gate.

    One instance per (pool_id, terminal_id). Construct it once and share
    among queue workers — the internal lock guarantees exclusivity.
    """

    def __init__(
        self,
        *,
        pool_id: UUID,
        terminal_id: UUID,
        terminal_path: str,
        account_details_loader: Callable[[UUID], Optional[AccountDetails]],
        session_ttl_s: float = 600.0,
        sticky_hold_ms: Optional[int] = None,
    ):
        self.pool_id = pool_id
        self.terminal_id = terminal_id
        self.terminal_path = terminal_path
        self.account_details_loader = account_details_loader
        self.session_ttl_s = session_ttl_s
        self.settings = get_v2_settings()
        self.sticky_hold_ms = (
            sticky_hold_ms
            if sticky_hold_ms is not None
            else self.settings.SESSION_STICKY_HOLD_MS
        )
        self._lock = threading.RLock()
        self._state = _SessionState()
        self.log = get_logger("session").bind(
            pool_id=str(pool_id),
            terminal_id=str(terminal_id),
        )

    # ── core ──────────────────────────────────────────────────────
    def _is_session_fresh(self, account_id: UUID) -> bool:
        if self._state.account_id != account_id:
            return False
        age = time.monotonic() - self._state.logged_in_at
        return age < self.session_ttl_s

    def _do_login(self, account_id: UUID, login: int) -> float:
        """Returns login_latency_ms. Raises LoginFailedError on failure."""
        t0 = time.monotonic()
        if _is_dry_run():
            # Simulate ~1s login cost (kept small for tests).
            time.sleep(0.05)
        else:
            try:
                import MetaTrader5 as mt5  # type: ignore
            except Exception as e:
                raise LoginFailedError(f"MetaTrader5 import failed: {e}")

            details = self.account_details_loader(account_id)
            if not details:
                raise LoginFailedError(f"account details not found for {account_id}")
            
            password = decrypt_mt5_password(details.encrypted_password)

            # 1) Initialize terminal (no-op if already running)
            # Path should point to terminal64.exe or its dir.
            exe = self.terminal_path
            if not exe.lower().endswith(".exe"):
                exe = os.path.join(exe, "terminal64.exe")

            ok = mt5.initialize(
                path=exe,
                timeout=self.settings.MT5_INIT_TIMEOUT_MS,
            )
            if not ok:
                raise LoginFailedError(
                    f"mt5.initialize failed: {mt5.last_error()}"
                )

            # 2) Perform login
            ok = mt5.login(
                login=details.login,
                password=password,
                server=details.server,
            )
            if not ok:
                err = mt5.last_error()
                raise LoginFailedError(f"mt5.login failed for {details.login}: {err}")

        latency_ms = (time.monotonic() - t0) * 1000.0
        self._state.account_id = account_id
        self._state.logged_in_at = time.monotonic()
        self._state.login_count += 1
        return latency_ms

    @contextmanager
    def acquire(self, *, account_id: UUID, login: int):
        """Hold the terminal for the given account.

        Yields a small dict with login_latency_ms (0 if sticky).
        """
        log = self.log.bind(account_id=str(account_id))
        acquired = self._lock.acquire(timeout=self.settings.SESSION_LOGIN_TIMEOUT_S)
        if not acquired:
            log.error("session lock timeout", extra={"action": "session_acquire_timeout"})
            raise LoginFailedError("session lock timeout")
        try:
            login_latency_ms = 0.0
            switched = False
            if self._is_session_fresh(account_id):
                log.info(
                    "session sticky reuse",
                    extra={"action": "session_reuse"},
                )
            else:
                try:
                    login_latency_ms = self._do_login(account_id, login)
                    switched = True
                    log.info(
                        "session login ok",
                        extra={
                            "action": "session_login",
                            "latency_ms": round(login_latency_ms, 2),
                            "dry_run": _dry_run(),
                        },
                    )
                except LoginFailedError as e:
                    log.error(
                        "session login failed",
                        extra={"action": "session_login_failed"},
                        exc_info=e,
                    )
                    # Mark account as failed in DB
                    try:
                        from . import repo
                        repo.mark_account_failed_credentials(account_id, str(e))
                    except Exception as repo_err:
                        log.error("failed to mark account status in repo", exc_info=repo_err)
                    raise
            yield {
                "login_latency_ms": login_latency_ms,
                "switched": switched,
                "login_count": self._state.login_count,
            }
            # Sticky hold: keep account "warm" briefly so back-to-back
            # tasks of the same account reuse the session.
            if self.sticky_hold_ms > 0:
                time.sleep(self.sticky_hold_ms / 1000.0)
        finally:
            self._lock.release()

    # ── introspection ─────────────────────────────────────────────
    def current_account(self) -> Optional[UUID]:
        return self._state.account_id

    def login_count(self) -> int:
        return self._state.login_count

    def has_open_positions(self) -> bool:
        """Check if current account has any open positions."""
        if _is_dry_run():
            return False # Simulation: assume clean
            
        with self._lock:
            try:
                import MetaTrader5 as mt5
                # Ensure we are initialized and logged in
                positions = mt5.positions_get()
                if positions is None:
                    # Error or no positions
                    return False
                return len(positions) > 0
            except Exception as e:
                self.log.error("failed to check positions", exc_info=e)
                return True # Safety first: assume has positions if error

